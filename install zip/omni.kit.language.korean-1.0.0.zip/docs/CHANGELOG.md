# Changelog

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

## [1.0.0] - 2025-11-16
- Created: Korean Language Extension  
  Adapted from `omni.kit.language.japanese-1.1.3` and customized to meet my needs.
  github: https://github.com/Hongdrew/ov-ext-language-korean
