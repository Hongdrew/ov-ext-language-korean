# Omniverse Korean Language and Font [omni.kit.language.korean]
