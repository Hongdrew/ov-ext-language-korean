"""
Implementation of Korean fontt
"""

from .korean import *
