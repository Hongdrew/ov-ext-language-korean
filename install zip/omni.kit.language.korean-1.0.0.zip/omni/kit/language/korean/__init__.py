"""
Implementation of Korean font
"""

from .scripts import *
